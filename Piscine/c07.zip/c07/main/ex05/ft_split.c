/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_split.c                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: njennes <njennes@student.42lyon.fr>        +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/08/24 10:13:25 by njennes           #+#    #+#             */
/*   Updated: 2021/08/24 11:52:46 by njennes          ###   ########lyon.fr   */
/*                                                                            */
/* ************************************************************************** */

#include <stdlib.h>

int	ft_strlen(char *str, char *charset, int mode);

int	ft_is_charset(char *str, char *charset)
{
	int	i;

	i = 0;
	while (charset[i] && str[i] == charset[i])
		i++;
	if (charset[i] == 0)
		return (1);
	return (0);
}

int	ft_strlen(char *str, char *charset, int mode)
{
	int	i;

	i = 0;
	if (mode)
	{
		while (str[i] && !ft_is_charset(str + i, charset))
			i++;
		return (i);
	}
	else
	{	
		while (str[i])
			i++;
		return (i);
	}
}

char	**ft_fill(char *str, char *charset, char **result, int tmp)
{
	int	i;
	int	j;

	i = 0;
	j = 0;
	while (str[i])
	{
		if (!ft_is_charset(str + i, charset))
		{
			result[j] = malloc(ft_strlen(str, charset, 1) * sizeof(char));
			if (!result)
				return (0);
			tmp = 0;
			while (!ft_is_charset(str + i, charset))
			{
				result[j][tmp] = str[i];
				i++;
				tmp++;
			}
			j++;
		}
		else
			i += ft_strlen(charset, "\0", 0);
	}
	return (result);
}

char	**ft_split(char *str, char *charset)
{
	int		blocks;
	int		offset;
	char	**result;

	blocks = 0;
	offset = 0;
	while (str[offset])
	{
		if (!ft_is_charset(str + offset, charset))
		{
			offset += ft_strlen(str + offset, charset, 1);
			blocks++;
		}
		else
			offset += ft_strlen(charset, "\0", 0);
	}
	result = malloc((blocks + 1) * sizeof(char *));
	if (!result)
		return (0);
	result[blocks] = 0;
	return (ft_fill(str, charset, result, 0));
}
